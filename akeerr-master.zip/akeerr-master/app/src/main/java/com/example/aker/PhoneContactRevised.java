package com.example.aker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import android.os.Bundle;
import android.provider.ContactsContract;
import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class PhoneContactRevised extends AppCompatActivity {


    private static int cntind = 1000;
    private static int[] sltcnt = new int[1000];
    public String[] s = new String[cntind];
    public String[] sn = new String[cntind];
    public static String[] snm;
    public static String[] sno;

    ListView listView;
    Button buttonNo, buttonYes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_contact_revised);



        listView = findViewById(R.id.listViewPhnContactRevised);
        buttonNo =findViewById(R.id.buttonNOPhncontactRev);
        buttonYes =findViewById(R.id.buttonYESPhncontactRev);

        for (int i = 0; i < cntind; i++) {
            s[i] = new String();
            sn[i] = new String();
        }

        Cursor cursor = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null,
                null, null);
        int ino = 0;

        while (cursor.moveToNext()) {

            s[ino] = new String(
                    cursor.getString(cursor
                            .getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));// name
            // of
            // contact

            sn[ino] = new String(
                    cursor.getString(cursor
                            .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)));// mobile
            // no.
            ino++;
        }

        snm = new String[ino];
        sno = new String[ino];

        String[] cntct = new String[ino];
        for (int i = 0; i < ino; i++) {
            // snm[i] = s[i];
            // sno[i] = sn[i];
            cntct[i] = s[i] + "\n" + sn[i];
        }

        ArrayAdapter<String> arr = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_multiple_choice, cntct);
        listView.setAdapter(arr);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        listView.setBackgroundResource(R.color.SkyBlue);



    }








}
